//
//  RepCell.h
//  Rep
//
//  Created by Hud on 3/7/13.
//  Copyright (c) 2013 Hud. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RepCell : UITableViewCell

@end
