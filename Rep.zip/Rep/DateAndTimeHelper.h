//
//  DateAndTimeHelper.h
//  Radius
//
//  Created by Radius on 9/25/12.
//
//

#import <Foundation/Foundation.h>

@interface DateAndTimeHelper : NSObject

- (NSString*)timeIntervalWithStartDate:(NSDate*)d1 withEndDate:(NSDate*)d2;

@end
