//
//  VenueViewController.h
//  Rep
//
//  Created by Hudson on 8/17/13.
//  Copyright (c) 2013 Hud. All rights reserved.
//

#import "RepViewController.h"

@interface VenueViewController : RepViewController

@end
