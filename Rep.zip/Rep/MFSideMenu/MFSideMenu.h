//
//  MFSideMenu.h
//
//  Created by Michael Frederick on 3/17/12.
//

#ifndef MFSideMenu_h
#define MFSideMenu_h

#import "MFSideMenuManager.h"
#import "UIViewController+MFSideMenu.h"

#endif
