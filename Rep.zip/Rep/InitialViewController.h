//
//  InitialViewController.h
//  Rep
//
//  Created by Hudson on 5/17/13.
//  Copyright (c) 2013 Hud. All rights reserved.
//

#import "RepViewController.h"

@interface InitialViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIImageView *backgroundImageViewOutlet;

@end
