//
//  NotificationsFind.h
//  radius
//
//  Created by Hud on 9/10/12.
//
//

#import <Foundation/Foundation.h>

@interface UIView (FindUIViewController)
- (UIViewController *) firstAvailableUIViewController;
- (id) traverseResponderChainForUIViewController;
@end
