//
//  NSString+URLEncoding.h
//  radius
//
//  Created by Radius on 10/9/12.
//
//

#import <Foundation/Foundation.h>
@interface NSString (URLEncoding)
-(NSString *)urlEncodeUsingEncoding:(NSStringEncoding)encoding;
@end
